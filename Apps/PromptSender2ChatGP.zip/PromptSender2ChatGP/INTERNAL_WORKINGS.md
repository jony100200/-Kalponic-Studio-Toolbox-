# PromptSender2ChatGP Internal Workings

Quick reference guide to how the app operates internally. For user docs, see README.md.

## Architecture Overview
- **Language**: Python
- **GUI**: CustomTkinter (modern, responsive interface)
- **Automation**: PyAutoGUI + keyboard simulation for window control
- **Structure**: Modular under `src/` (core logic, GUI, automation)
- **Threading**: Non-blocking processing via threads
- **Config**: JSON-based settings persistence

## Key Scripts & Flow

### 1. Entry Points
- **`main.py`**: Launches GUI. Sets up logging, loads config, runs `PromptSequencerGUI`.
- **`cli.py`**: CLI tools for testing (windows, focus, deps, etc.). Imports from `src/`.
- **`run.bat`**: Simple wrapper to run `main.py`.

### 2. Core Modules (`src/`)

#### `src/core/config.py`
- Manages `settings.json` (user prefs, delays, etc.).
- Methods: load/save, defaults handling.
- Used by GUI and sequencer.

#### `src/gui/main_window.py`
- Main window class (`PromptSequencerGUI`).
- Creates scrollable tabbed UI (Text Mode, Image+Text Mode).
- Handles resizing, threading, callbacks (start/pause/resume).
- Initializes sequencer and automation.

#### `src/gui/components.py`
- UI components: ControlPanel, StatusPanel, TextModeTab, ImageModeTab (with queue UI), LogPanel.
- ImageModeTab: Single folder vs. queue mode; dynamic enqueue (add/remove/move folders).

#### `src/core/sequencer.py`
- Core processor (`PromptSequencer` class).
- Runs in thread; processes prompts/images.
- **Text Mode**: Reads .txt, splits by `---`/blanks, pastes with delays.
- **Image Mode**: Pastes images (jpg/png/etc.), waits (configurable delay), then text.
- **Queue Mode**: Thread-safe queue for batch folders; dynamic add/remove.
- Automation: Focus window, paste, retry on fail, move files to `sent_*/` or `failed/`.
- Callbacks: Update GUI (progress, logs, manual intervention).

#### `src/automation/automation.py`
- Window detection (`WindowDetector`): Finds windows by title.
- Focus strategies: Browser (Ctrl+L+Tab), Generic (Ctrl+K/etc.), Tab nav.
- Input sim: PyAutoGUI for paste/click; clipboard safety.
- Verification: Pastes `<<<TEST>>>` to check focus.

### 3. Execution Flow
1. **Launch**: `main.py` → Load config → GUI (`main_window.py`).
2. **Setup**: User configures window, mode, folders.
3. **Process**: GUI starts sequencer thread → Detect/focus window → Loop: paste content → wait → move file → update UI.
4. **Queue**: Maintains live queue; processes sequentially; supports runtime add/remove.
5. **Logging**: To `logs/*.log` and GUI panel.
6. **Exit**: Save config, cleanup.

### 4. Dependencies (`requirements.txt`)
- `customtkinter`: GUI
- `pyautogui`: Automation
- `pyperclip`: Clipboard
- `keyboard`: Key sim
- `pygetwindow`: Window detection
- `Pillow`: Image handling

### 5. Data Flow
- Input: .txt files (prompts) or image folders
- Processing: Automation pastes to target window (e.g., ChatGPT)
- Output: Moved to `sent_prompts/` or `sent_images/`; failed to subfolders
- Config: `settings.json`
- Logs: `logs/`

### 6. Key Features Internals
- **Responsive GUI**: Auto-sizes (80% screen, min 800x600); scrollable.
- **Queue Mode**: Uses `queue.Queue`; callbacks remove processed items.
- **Focus**: Multiple strategies with retries; manual fallback.
- **Safety**: PyAutoGUI failsafe (mouse top-left); clipboard restore.
- **Threading**: Sequencer in background; GUI updates via callbacks.

### 7. Testing/CLI
- `cli.py` commands: `deps`, `windows`, `focus`, `strategies`, `sample_prompts`, `test_gui`, `config`.
- Samples in `sample_prompts/`, `test_prompts/`.
- Templates in `UNiversal Prompt Templates/`.

For code changes, refer to `src/` structure. GUI in `main_window.py`, logic in `sequencer.py`.