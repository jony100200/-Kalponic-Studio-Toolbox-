# Automation Design & Strategy

Purpose
- Capture feasibility, architecture, integration options, validation strategies, and a recommended roadmap for evolving the PromptSender2ChatGP tool into an income-generating automation/agent platform that can drive tools such as ChatGPT/Grok, VS Code, Visual Studio, Unity, and other desktop/web apps.

Executive summary
- The app already provides reliable clipboard-based paste automation, window detection, retries, and a queue system. This can be extended to support editor targets (VS Code/Visual Studio), headless APIs (ChatGPT/Grok), and more robust validation.
- Short term (fast wins): add target-specific keyboard focus strategies, optional click-record fallbacks, and a validation engine using copy/parse and optional OCR.
- Longer term (recommended): implement per-target adapters — lightweight VS Code/Visual Studio extension or command endpoints — and prefer API-first integrations for chat services where possible.

Goals (what this system should achieve)
- Run prompt sequences unattended and reliably against a target application.
- Validate responses and optionally branch or retry based on validation.
- Support multiple target types with clear adapters (web chat UIs, desktop chat clients, code editors, game engines).
- Provide tooling to record fallback click points and to dry-run sequences to help configuration.

Scope and constraints
- Target platforms are desktop Windows (primary) where current clipboard + pyautogui automation works.
- Some targets (web chat UIs, extension webviews) may not expose selectable text; validation then requires OCR unless using official APIs.
- DPI scaling, custom VS Code layout, and user themes may affect coordinate-based fallbacks — therefore keyboard-first strategies are preferable.

High-level architecture
- Sequencer (existing): scheduler/worker that consumes a sequence of steps and executes them in order. Should support linear and conditional flows.
- Automation layer (existing `src/automation/automation.py` + additions):
  - Window detection & activation (pygetwindow)
  - Focus strategies (keyboard sequences per target)
  - Click fallback utilities (relative to window bounds; user-recordable offsets)
  - Clipboard manager (already present)
  - Paste controller (text/image)
- Target adapters (new): small modules for each target type that encapsulate focus, paste, and validation strategies. Example adapters: `web_chat_adapter`, `vscode_adapter`, `visualstudio_adapter`, `unity_adapter`, `api_adapter`.
- Validation engine: pluggable validators (copy-then-parse, screenshot+OCR, API response parsing) with matchers (regex, JSON assertions, simple keywords) and timeout/retry semantics.
- Config & persistence: `settings.json` holds target defaults, fallback offsets, API keys (prefer secure store), queue items.
- CLI & recorder: tools to test focus strategies, record fallback click points, and dry-run sequences.
- Logging & audit: detailed logs per step, move inputs to `sent_*/`, keep `failed/` folder for failed steps, and optionally store sequence runs.

Integration approaches (pros/cons)
1) UI Automation Only (keyboard + optional click fallback)
   - Pros: No code changes to target apps; fastest to ship.
   - Cons: Fragile for webviews/embedded UIs and non-standard layouts. Validation requires OCR or copyable outputs.

2) API-First for chat services
   - Pros: Reliable, fast, exact responses available for deterministic validation. Best for ChatGPT/Grok if API access is acceptable.
   - Cons: Cost (API usage), possible rate limits, and may bypass the UX (less realistic simulation of UI).

3) Extension / Plugin for editors (VS Code/Visual Studio)
   - Pros: Very reliable integration; can expose commands to receive prompts and return outputs programmatically. Supports structured validation and faster iteration.
   - Cons: Requires writing and maintaining small extensions; additional release/installation steps for users.

4) Hybrid (recommended)
   - Use APIs where available and acceptable.
   - Use keyboard-first automation for general apps and implement small per-target adapters for complex targets (e.g., VS Code extension) with a fallback to click-based automation.

Target-specific notes
- ChatGPT / Grok (web UI): API calls are preferred. If UI must be used, use keyboard focus strategies that put the caret in the message box and paste; validate via copy-select or OCR of the response region.
- VS Code: keyboard-focused approach (e.g., `Ctrl+1`, `Ctrl+` N to focus editor group) can reliably place caret in editor. For extension-based chat panes (webviews), implement either an extension exposing a `focusChatInput` command or use recorded click fallback.
- Visual Studio: similar to VS Code; many commands exist for focusing windows/panels. Consider a small VS extension for deep integration.
- Unity / Game engines: better to run headless scripts (Editor scripting, command-line build) rather than UI automation. Use Unity's batch mode or remote commands for deterministic builds and validation.

Validation strategies (detailed)
- Copy-and-parse (best for editors & terminals): select response text, copy to clipboard, parse with regex or structured rules. Fast and reliable where selectable.
- API response check (best for chat services when using API): validate returned JSON or text directly.
- Screenshot + OCR (fallback): take screenshot of a response region, run OCR. Works everywhere but slower and less accurate.
- Execution & test-run (for build artifacts): run unit tests, smoke tests, or simple runtime checks (e.g., run a tiny game scene) and validate artifacts.

Sequence model (suggested JSON schema)
- Each step is:
  {
    "id": "step-1",
    "target": {
      "app": "vscode",
      "subtype": "editor",
      "identifier": "Visual Studio Code",
      "fallback_click": {"x": 0.5, "y": 0.92}  // relative coords inside window
    },
    "action": "paste_text", // paste_image, run_command
    "content": "Create a new C# script named PlayerController...",
    "auto_enter": true,
    "validate": {
      "method": "copy_parse",
      "matcher": "Compilation succeeded|class PlayerController",
      "timeout": 10
    },
    "on_fail": {
      "retry": 2,
      "next": "step-fail-handler"
    },
    "on_success": {
      "next": "step-2"
    }
  }

MVP recommendation (phase 1)
- Keep the existing sequencer but extend `src/automation/automation.py` with:
  - `vscode_focus_strategy` keyboard sequence.
  - Click-record fallback (small CLI command that stores offset in `settings.json`).
  - Add `target_subtype` to `settings.json` and per-queue-item metadata.
- Add a validator that supports `copy_parse` and `ocr`.
- Add a `dry-run` CLI to validate focus & verification markers without sending prompts.

Phase 2 (medium term)
- Add API adapters for ChatGPT and other LLM services (configurable API keys).
- Add a small VS Code extension (optional) that exposes a `promptReceiver` command to accept pasted prompts and return evaluation output to the app (via local WebSocket or command output), enabling reliable validation.
- Add branching logic in sequences (if/else) and richer retry policies.

Phase 3 (long term)
- Build a simple orchestration UI for scheduling runs, viewing run history, and replaying runs.
- Add user/team authentication and secure credential storage for API keys.
- Add a marketplace for selling prompt sequences, templates, and adapters.

Security, cost & reliability
- API usage costs: estimate costs for ChatGPT/Grok usage; provide configuration to toggle API vs UI automation.
- API keys must not be committed; store in secure local store or environment variables.
- Automation risks: accidental destructive actions — add safety features (dry-run, confirmation step, undo logs, rate limiting).

Implementation notes and tools
- Use `pygetwindow` + `pyautogui` (already used) for activation + keyboard automation.
- Use `pyperclip` for clipboard operations.
- Use `pytesseract` (optional) or cloud OCR for higher-accuracy OCR if local accuracy is poor.
- For VS Code extension: implement a small TypeScript extension exposing a command or a local WebSocket server inside extension host for structured communication.

Example quick workflows
- Use-case A (asset generation):
  1. Send prompt to image-generator or ChatGPT (API) to create asset specs.
  2. Generate assets via headless tools or scripts (Unity command-line, external tools).
  3. Run validation scripts (does asset meet size/format?), add to `sent_images/` and log success.

- Use-case B (code scaffolding + build):
  1. Send prompts to ChatGPT to create scaffolding code.
  2. Paste code into `vscode` (editor adapter) and save files.
  3. Trigger build (VS Code task or CLI `dotnet build`).
  4. Capture build output; validate success via copy_parse.

Roadmap & estimated effort (very rough)
- Phase 1 (keyboard strategies + validator + recorder): 1-2 weeks
- Phase 2 (API adapters + VS Code extension + branching): 2-4 weeks
- Phase 3 (orchestration UI + marketplace + secure storage): 4+ weeks

Next steps for you to pick
- Option 1 (Fast): Implement keyboard-only VS Code strategy + copy_parse validator + click-record fallback.
- Option 2 (Robust): Do Option 1, then add ChatGPT API adapter and a small VS Code extension (hybrid).
- Option 3 (Ambitious): Full pipeline with orchestration UI and marketplace (long term).

If you confirm Option 1 or 2 I will produce a concrete implementation plan and start with the automation changes and CLI recorder.

Appendix: quick CLI commands to test focus (examples)
```powershell
# Test focusing a window by title
python cli.py windows
python cli.py focus --window "Visual Studio Code"

# Dry-run focus verification (no paste)
python cli.py focus --window "Visual Studio Code" --verify-only
```



